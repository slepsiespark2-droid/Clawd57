// cartoon.js: "Tomorrow's Friend" - Clawd chases a butterfly, gives up, and it lands on him.
(() => {
  const G = 860, U = 26;
  const ORANGE = PAL.clay;
  const hillY = (x, cx, cy, rx, ry) => cy - ry * Math.sqrt(Math.max(0, 1 - ((x - cx) / rx) ** 2));
  const HILL = [620, 1060, 820, 200];

  // ---------- world ----------
  function backdrop(t, hill, tone = 0, gray = 0) {
    const dk = c => { c = mixCol(c, '#8A929E', gray * .55); return tone === 2 ? mixCol(c, PAL.night, .6) : tone === 3 ? mixCol(c, PAL.rose, .18) : c; };
    const skyC = tone === 2 ? '#2A3366' : tone === 3 ? mixCol('#F2A283', PAL.cream, .5) : mixCol(mixCol(PAL.sky, PAL.cream, .62), '#8A929E', gray * .6);
    boilSeed('sky');
    paint(rectPts(-600, -400, W + 3600, H + 800), { wash: skyC, ink: null });
    if (tone === 2) {
      for (let i = 0; i < 70; i++) { boilSeed('st' + i); const tw = .55 + .45 * Math.sin(t * (2 + 2 * hash(i + 300)) + i); paint(starPts(hash(i) * (W + 400) - 100, hash(i + 100) * 560, (3 + 5 * hash(i + 200)) * tw, .35, 4), { wash: PAL.cream, washOp: 150 + 100 * tw, ink: null }); }
      boilSeed('moon'); paint(ellPts(1560, 200, 95, 95, 28, 1.5), { wash: '#FFF1C8', ink: PAL.ink, sw: .9 }); paint(ellPts(1600, 176, 82, 82, 28, 1), { wash: skyC, ink: null });
    } else {
      boilSeed('sun'); paint(ellPts(1560, 190, 78, 78, 24, 1.6), { wash: '#FFD96A', ink: PAL.ink, sw: .8 });
      for (let i = 0; i < 12; i++) { const a = i * .52 + t * .3; inkLine([[1560 + Math.cos(a) * 105, 190 + Math.sin(a) * 105], [1560 + Math.cos(a) * 132, 190 + Math.sin(a) * 132]], .8, PAL.ochre, 'inkfine', 0); }
      for (let i = 0; i < 5; i++) {
        boilSeed('cloud' + i);
        const cx = ((hash(i) * 3400 + t * 14 * (.6 + hash(i + 9))) % 3600) - 300, cy = 140 + 110 * hash(i + 5), cc = mixCol(PAL.cream, '#8A929E', gray * .5);
        paint(ellPts(cx, cy, 120, 36, 20, 2), { wash: cc, ink: PAL.ink, sw: .7 });
        paint(ellPts(cx - 40, cy - 26, 62, 32, 16, 2), { wash: cc, ink: PAL.ink, sw: .7 });
      }
    }
    boilSeed('far');
    paint(ellPts(500, 960, 900, 230, 36, 3), { wash: dk(mixCol(PAL.sap, PAL.cream, .65)), ink: PAL.ink, sw: .8 });
    paint(ellPts(1700, 980, 1000, 250, 36, 3), { wash: dk(mixCol(PAL.teal, PAL.cream, .6)), ink: PAL.ink, sw: .8 });
    paint(ellPts(2900, 960, 900, 230, 36, 3), { wash: dk(mixCol(PAL.sap, PAL.cream, .65)), ink: PAL.ink, sw: .8 });
    boilSeed('ground');
    const gc = dk(mixCol(PAL.sap, PAL.cream, .3));
    if (hill) paint(ellPts(...HILL, 44, 2), { wash: gc, ink: PAL.ink, sw: 1.1 });
    else {
      paint(rectPts(-300, G - 6, W + 3600, 600, 3), { wash: gc, ink: null });
      inkLine([[-300, G - 6], [900, G - 12], [2400, G - 4], [3400, G - 8]], 1.1, PAL.ink, 'ink', .5);
    }
    const FL = [PAL.rose, PAL.ochre, PAL.violet, PAL.cream];
    for (let i = 0; i < 34; i++) {
      boilSeed('fl' + i);
      let x = hash(i + 40) * 3200 - 200; if (hill && (x < -100 || x > 1250)) x = hash(i) * 1250;
      const gy = hill ? hillY(x, ...HILL) : G + 6 + 40 * hash(i + 70);
      if (hill && Math.abs(x - 620) < 130) continue;
      const sway = wob(t, .5, hash(i) * 6) * 5, h = 26 + 24 * hash(i + 3), sc = dk(mixCol(PAL.sap, PAL.ink, .4));
      inkLine([[x, gy + 6], [x + sway * .5, gy - h * .5], [x + sway, gy - h]], .8, sc, 'inkfine', .6);
      if (i % 3 === 0) paint(ellPts(x + sway, gy - h - 6, 9, 9, 10, 1), { wash: dk(FL[i % 4]), ink: PAL.ink, sw: .6 });
      else for (const k of [-1, 0, 1]) inkLine([[x + k * 7, gy + 4], [x + k * 11 + sway, gy - 12 - 10 * hash(i + k)]], .7, sc, 'inkfine', .4);
    }
  }

  // butterfly: s = size, flap rate fr (rad/s); open 0..1 limits the flap (folded wings when resting)
  function bfly(x, y, s, t, o = {}) {
    boilSeed('bf');
    const fr = o.fr ?? 16, open = o.open ?? 1, w = lerp(.15, .25 + .75 * Math.abs(Math.sin(t * fr)), open), rot = o.rot || 0;
    push(); translate(x, y); rotate(rot);
    for (const sd of [-1, 1]) {
      paint(ellPts(sd * s * .72 * w, -s * .38, s * .75 * w, s * .6, 16, 1.2, sd * .45), { wash: PAL.violet, ink: PAL.ink, sw: .9 });
      paint(ellPts(sd * s * .5 * w, s * .38, s * .5 * w, s * .38, 14, 1, -sd * .35), { wash: PAL.rose, ink: PAL.ink, sw: .9 });
      if (w > .35) paint(ellPts(sd * s * .85 * w, -s * .42, s * .17 * w, s * .15, 8, .5), { wash: PAL.cream, ink: null });
    }
    paint(ellPts(0, 0, s * .1, s * .55, 10, .5), { wash: PAL.ink, ink: null });
    for (const sd of [-1, 1]) inkLine([[0, -s * .5], [sd * s * .3, -s * .9]], .8, PAL.ink, 'inkfine', .4);
    pop();
  }

  // ---------- timeline + titles + iris ----------
  function timeline(era, lt) {
    boilSeed('tl');
    const xs = [-3, -2, -1, 0, 1, 2, 3].map(i => 960 + i * 68), y = 1016;
    inkLine(xs.map((c, i) => [c, y + (i % 2) * 2]), 1.4, mixCol(PAL.ink, PAL.paper, .35), 'ink', .3);
    for (let i = 0; i < 7; i++) {
      const on = i <= era, here = i === era, r = here ? 15 + 2.5 * pulse(lt + .2, 3) : 10;
      paint(ellPts(xs[i], y, r, r, 16, 1.2), { wash: on ? ORANGE : PAL.cream, ink: PAL.ink, sw: 1 });
    }
  }
  function title(txt, lt, closeAt, era) {
    const a = seg(lt, .55, .75) * (1 - seg(lt, closeAt - .25, closeAt));
    if (a <= 0) return;
    letter(txt, 70, 120, 92, ORANGE, { pop: (lt - .55) * 4, alpha: a, rot: -.04, screen: true, align: 'left' });
    const k = easeOut(seg(lt, .8, 1.25));
    if (k > 0 && a > .5) { boilSeed('ul'); inkLine([[70, 188], [lerp(70, 70 + txt.length * 17, k), 192], [lerp(70, 70 + txt.length * 36, k), 186]], 3.2, ORANGE, 'ink', .5); }
  }
  function irisFx(cx, cy, r) {
    iris(cx, cy, r, PAL.ink);
    if (r > 30 && r < 1500) {
      boilSeed('speed');
      for (let i = 0; i < 40; i++) {
        const a = i / 40 * TAU + hash(i) * .1, len = 60 + 170 * hash(i + 50), r0 = r + 28 + 20 * hash(i + 9);
        inkLine([[cx + Math.cos(a) * r0, cy + Math.sin(a) * r0], [cx + Math.cos(a) * (r0 + len), cy + Math.sin(a) * (r0 + len)]], 1.3, PAL.cream, 'ink', 0);
      }
    }
  }
  const irisOpen = (lt, cx, cy, d = .55) => { if (lt < d) irisFx(cx, cy, lerp(0, 1700, easeIn(lt / d))); };
  const irisClose = (lt, dur, cx, cy, d = .6) => { if (lt > dur - d) irisFx(cx, cy, lerp(1700, 0, ease((lt - (dur - d)) / d))); };

  // ---------- shot A: Nap ----------
  function shotNap(t, lt, dur) {
    camBegin(960 + 14 * Math.sin(lt * .5), 540, 1.04 - .01 * lt);
    backdrop(t, true);
    const mood = emotions(lt, [[0, 'sleepy'], [2.0, 'surprised', { lookX: .9, lookY: -.3 }], [2.85, 'excited', { lookX: 1 }]]);
    const bf = kf(lt, [[.7, [2150, 380]], [1.5, [1500, 470]], [2.0, [880, 600]], [2.6, [760, 560]], [3.0, [900, 540]], [3.7, [1750, 300]]], ease);
    const by = bf[1] + 22 * Math.sin(lt * 5);
    const facing = lt < 3.1 ? {} : lt < 3.25 ? turn(lt, 3.1, 3.25, 0, .25) : { view: 'side' };
    const hop = jump(lt, 3.55, 3.95, 1.5);
    clawd(620, G, U, { ...mood, ...facing, sq: (mood.sq || 0) + hop.sq, dy: (mood.dy || 0) + hop.dy });
    bfly(bf[0], by, 44, lt, { rot: .15 * Math.sin(lt * 3) });
    const eye = toScreen(620, G - 4 * U);
    camEnd();
    timeline(0, lt); title('Nap', lt, dur, 0);
    irisOpen(lt, 960, 540); irisClose(lt, dur, ...eye);
  }

  // ---------- shot B: Chase ----------
  function shotChase(t, lt, dur) {
    const u = 24;
    const cx = kf(lt, [[0, 880], [1.7, 1700], [2.5, 2000], [dur, 2050]], ease);
    const run = lt < 1.72 ? lerp(500, 1500, ease(seg(lt, 0, 1.7)) * .4 + seg(lt, 0, 1.7) * .6) : null;
    const lunge = arcPt([1500, G], [1780, G], 180, seg(lt, 1.75, 2.45));
    const x = lt < 1.72 ? run : lt < 2.45 ? lunge[0] : 1780 + 70 * easeOut(seg(lt, 2.45, 3.0));
    camBegin(cx, 540, 1.02);
    backdrop(t, false);
    const mood = emotions(lt, [[0, 'determined'], [2.5, 'surprised'], [2.95, 'sad'], [3.7, 'hopeful', { lookX: .5, lookY: -.9 }]]);
    let pose, bx, by;
    if (lt < 1.72) { const d = (x - 500) / (4 * u); pose = { view: 'side', walk: d, dy: -Math.abs(Math.sin(d * Math.PI)) * .6, aL: -.4, aR: -.4 }; }
    else if (lt < 2.45) { const j = jump(lt, 1.75, 2.45, 0.01); pose = { view: 'side', aL: 1.3, aR: 1.3, sq: j.sq, dy: (lunge[1] - G) / u, rot: -.25 * Math.sin(seg(lt, 1.75, 2.45) * Math.PI) }; }
    else pose = { view: 'side', aL: 1.1 * Math.exp(-(lt - 2.45) * 3), aR: .6 * Math.exp(-(lt - 2.45) * 3), sq: .25 * Math.exp(-(lt - 2.45) * 6) * Math.cos((lt - 2.45) * 16) };
    const sad = lt > 3.0 ? { view: 'q' } : {};
    clawd(x, G, u, { ...mood, ...pose, ...sad, sq: (mood.sq || 0) + (pose.sq || 0), dy: (lt < 2.95 ? 0 : mood.dy || 0) + (pose.dy || 0), rot: pose.rot || 0 });
    // butterfly: always just ahead, flits away on the lunge, circles back at the end
    if (lt < 2.2) { bx = (lt < 1.72 ? x : lunge[0]) + 330 + 40 * Math.sin(lt * 3); by = 620 + 70 * Math.sin(lt * 4.5); }
    else if (lt < 3.4) { const k = ease(seg(lt, 2.2, 2.9)); bx = lerp(x + 360, 2260, k) + 30 * Math.sin(lt * 3); by = lerp(620, 300, k) + 20 * Math.sin(lt * 5); }
    else { const k = ease(seg(lt, 3.4, dur)); bx = lerp(2260, x + 190, k); by = lerp(300, 520, k) + 30 * Math.sin(lt * 5); }
    bfly(bx, by, 44, lt, { rot: .15 * Math.sin(lt * 3) });
    const eye = toScreen(x, G - 4 * u);
    camEnd();
    timeline(1, lt); title('Chase', lt, dur, 1);
    irisOpen(lt, 960, 540); irisClose(lt, dur, ...eye);
  }

  // ---------- shot C: Friends ----------
  function shotFriends(t, lt, dur) {
    camBegin(960 + 12 * Math.sin(lt * .5), 540, 1.04 - .008 * lt);
    backdrop(t, true);
    const mood = emotions(lt, [[0, 'sad'], [1.0, 'hopeful', { lookX: .8, lookY: -.5 }], [2.3, 'starstruck', { lookX: .5, lookY: -.9 }],
      [3.1, 'surprised', { lookY: -1, lookX: 0 }], [3.9, 'love'], [4.9, 'sleepy']]);
    const sq = (mood.sq || 0), dy = (mood.dy || 0);
    clawd(620, G, U, { ...mood, view: 'front', sq, dy });
    const head = [630, G + dy * U - 8 * U * (1 - sq) - 4];
    let bx, by, open = 1, fr = 16;
    if (lt < .6) { bx = 2150; by = 320; }
    else if (lt < 3.0) { const p = kf(lt, [[.6, [2150, 320]], [1.8, [1000, 470]], [2.4, [760, 520]], [3.0, [head[0], head[1] - 30]]], ease); bx = p[0]; by = p[1] + 18 * Math.sin(lt * 5) * (1 - seg(lt, 2.4, 3.0)); }
    else { bx = head[0]; by = head[1] - 22; open = .55 + .45 * Math.abs(Math.sin((lt - 3.0) * 1.8)); fr = 4; }
    bfly(bx, by, 44, lt, { open: lt > 3.0 ? open : 1, fr: lt > 3.0 ? 3 : 16, rot: lt > 3 ? 0 : .15 * Math.sin(lt * 3) });
    const eye = toScreen(620, G - 4 * U);
    camEnd();
    timeline(2, lt); title('Friends', lt, dur, 2);
    irisOpen(lt, ...eye); irisClose(lt, dur, ...eye, .75);
  }

  // ---------- new scenes ----------
  const headAt = (sq = 0) => [630, G - 8 * U * (1 - sq) - 30];
  const BX = [620, 560];
  function bigFlower(px, gy, k, t) {
    const h = 200 * easeOut(k), sw = Math.sin(t * 2) * 5 * k;
    boilSeed('bigfl'); inkLine([[px, gy], [px + sw * .5, gy - h * .5], [px + sw, gy - h]], 2.6, mixCol(PAL.sap, PAL.ink, .4), 'ink', .6);
    if (k > .3) { const r = 34 * Math.min(1.1, backOut(seg(k, .3, 1)));
      for (let i = 0; i < 6; i++) { const a = i * 1.047; paint(ellPts(px + sw + Math.cos(a) * r * 1.1, gy - h + Math.sin(a) * r * 1.1, r * .8, r * .8, 14, 1), { wash: PAL.rose, ink: PAL.ink, sw: .9 }); }
      paint(ellPts(px + sw, gy - h, r * .7, r * .7, 14, 1), { wash: PAL.ochre, ink: PAL.ink, sw: .9 }); }
  }
  const sumPose = (m, p) => ({ ...m, ...p, sq: (m.sq || 0) + (p.sq || 0), dy: (m.dy || 0) + (p.dy || 0) });

  // D: Picnic (8.0 .. 10 s): a flower grows, the butterfly sips, Clawd dances on the beat
  function shotPicnic(t, lt, dur) {
    camBegin(960 + 10 * Math.sin(lt * .4), 540, 1.03);
    backdrop(t, true);
    const fx = 1060, fy = hillY(fx, ...HILL); bigFlower(fx, fy, seg(lt, 1.4, 3.2), t);
    const mood = emotions(lt, [[0, 'neutral'], [1.4, 'surprised', { lookX: .8, lookY: -.3 }], [3.2, 'happy'], [5.0, 'playful'], [8.2, 'proud'], [9.2, 'happy']]);
    const dance = lt > 5 && lt < 8.2 ? move('bounce', t, 1) : {};
    const cl = sumPose(mood, dance); if (!(lt > 5 && lt < 8.2)) { cl.aL = mood.aL; cl.aR = mood.aR; }
    clawd(620, G, U, cl);
    const top = [fx, fy - 232], h = headAt(cl.sq || 0), base = kf(lt, [[0, BX], [1.4, BX], [3.6, top], [5.0, top], [5.8, BX], [8.2, BX], [9.2, [h[0], h[1] - 22]]], ease);
    const amp = lt < 1.4 ? 1 : lt < 2.4 ? 1 - seg(lt, 1.4, 2.4) : lt < 5 ? 0 : lt < 5.8 ? seg(lt, 5, 5.8) : lt < 8.2 ? 1 : 1 - seg(lt, 8.2, 9);
    const perch = (lt > 3.6 && lt < 5) || lt > 9.2;
    bfly(base[0] + amp * 170 * Math.cos(lt * 2.4), base[1] + amp * 60 * Math.sin(lt * 4.8) + (perch ? 0 : 16 * Math.sin(lt * 5)), 44, lt, { open: perch ? .5 + .5 * Math.abs(Math.sin(lt * 2)) : 1, fr: perch ? 3 : 16, rot: perch ? 0 : .15 * Math.sin(lt * 3) });
    const eye = toScreen(620, G - 4 * U); camEnd();
    timeline(3, lt); title('Picnic', lt, dur, 3);
    irisOpen(lt, ...eye); irisClose(lt, dur, ...eye);
  }

  // E: Rain: a cloud arrives, a leaf umbrella, sun and a rainbow
  function leafUmb(a, b, cx, cy, k) {
    boilSeed('leaf'); inkLine([a, b], 2.6, mixCol(PAL.sap, PAL.ink, .5), 'ink', .3);
    paint(ellPts(cx, cy, 190 * k, 46 * k, 24, 2), { wash: '#5E9A4E', ink: PAL.ink, sw: 1 });
    inkLine([[cx - 170 * k, cy + 2], [cx + 170 * k, cy - 2]], .8, '#3F6B38', 'inkfine', .3);
  }
  function shotRain(t, lt, dur) {
    camBegin(960, 540, 1.03);
    const clear = seg(lt, 6.8, 8.8), gray = seg(lt, 1, 2.6) * (1 - clear);
    backdrop(t, true, 0, gray);
    const pr = clear > 0 ? easeOut(seg(lt, 7.4, 9)) : 0;
    if (pr > .02) ['#E27A92', '#E8AA38', '#FFD96A', '#6E9F58', '#3A9C98', '#7B5CA8'].forEach((c, i) => {
      boilSeed('rb' + i); const P = []; const r = 560 - i * 20;
      for (let n = 0; n <= 14; n++) { const a = Math.PI + Math.PI * pr * n / 14; P.push([1320 + Math.cos(a) * r, G + 90 + Math.sin(a) * r]); }
      paint(ribbon(P, 16, 16), { wash: c, ink: null });
    });
    const cxp = kf(lt, [[0, -300], [2.4, 640], [6.6, 660], [9, 2300]], ease), cy = 300, lk = backOut(seg(lt, 3.6, 4.2)) * (1 - seg(lt, 7.0, 7.6)), cyl = G - 8 * U - 130;
    const rk = lt > 2.4 && lt < 7.4 ? seg(lt, 2.4, 3) * (1 - seg(lt, 6.8, 7.4)) : 0;
    boilSeed('cloud');
    for (const [dx, dy, rx, ry] of [[0, 0, 200, 60], [-90, -40, 110, 50], [80, -50, 120, 55]]) paint(ellPts(cxp + dx, cy + dy, rx, ry, 20, 2), { wash: '#9AA3B2', ink: PAL.ink, sw: .9 });
    if (rk > .02) for (let i = 0; i < 70; i++) {
      boilSeed('rain' + i);
      const x0 = cxp + (hash(i) - .5) * 420, y = cy + 50 + ((lt * 1100 * (.8 + .4 * hash(i + 3)) + hash(i + 9) * 900) % 700);
      if (y > G + 30 || (lk > .1 && Math.abs(x0 - 700) < 190 * lk && y > cyl - 10)) continue;
      if (hash(i + 77) < rk) inkLine([[x0, y], [x0 - 6, y + 26]], .9, '#5B7FB5', 'inkfine', 0);
    }
    const mood = emotions(lt, [[0, 'happy'], [2.0, 'surprised', { lookY: -1 }], [2.7, 'sad'], [3.7, 'hopeful'], [7.0, 'surprised', { lookX: .8 }], [7.8, 'excited']]);
    const cheer = lt > 7.8 ? move('bounce', t, 2) : {};
    const cl = sumPose(mood, cheer); if (lt <= 7.8) { cl.aL = mood.aL; cl.aR = mood.aR; } if (lk > .05) cl.aR = 1.2;
    clawd(620, G, U, cl);
    if (lk > .02) leafUmb([620 + 5 * U + Math.cos(1.2) * U * 1.9, G - 4.5 * U - Math.sin(1.2) * U * 1.9], [700, cyl], 700, cyl, lk);
    const h = headAt(cl.sq || 0), hov = [620 + 170 * Math.cos(lt * 2.4), 560 + 60 * Math.sin(lt * 4.8)];
    const b = lt < 2.4 ? hov : kf(lt, [[2.4, hov], [3.9, [h[0], h[1] - 22]], [7.4, [h[0], h[1] - 22]], [8.4, [900, 400]], [11, [1300, 430]]], ease);
    const per = lt > 3.9 && lt < 7.4;
    bfly(b[0], b[1] + (per ? 0 : 14 * Math.sin(lt * 5)), 44, lt, { open: per ? .3 : 1, fr: per ? 3 : 16, rot: per ? 0 : .15 * Math.sin(lt * 3) });
    const eye = toScreen(620, G - 4 * U); camEnd();
    timeline(4, lt); title('Rain', lt, dur, 4);
    irisOpen(lt, ...eye); irisClose(lt, dur, ...eye);
  }

  // F: Night: fireflies, a shooting star, a wish, sleep with the butterfly on his head
  function shotNight(t, lt, dur) {
    camBegin(960 + 10 * Math.sin(lt * .4), 540, 1.03);
    backdrop(t, true, 2);
    for (let i = 0; i < 14; i++) {
      boilSeed('ff' + i);
      const px = hash(i) * 1500 + 30 * Math.sin(t * .6 + i), py = 620 + hash(i + 30) * 320 + 20 * Math.sin(t * .9 + i * 2), a = .5 + .5 * Math.sin(t * 2 + i * 3);
      glow(px, py, 26 + 10 * a, '#FFE9A8', .35 + .5 * a);
    }
    const ss = seg(lt, 4.2, 5.3);
    if (ss > 0 && ss < 1) {
      const p = easeIn(ss), P = []; for (let n = 6; n >= 0; n--) { const q = Math.max(0, p - n * .05); P.push([lerp(1500, 700, q), lerp(80, 430, q)]); }
      boilSeed('shoot'); paint(ribbon(P, 2, 14), { wash: PAL.cream, ink: null }); glow(...P[6], 40, '#FFF1B8', .8);
    }
    const mood = emotions(lt, [[0, 'neutral', { lookX: .3, lookY: -.9 }], [4.4, 'surprised', { lookX: .9, lookY: -.9 }], [5.8, 'hopeful', { lookY: -.5 }], [7.0, 'love'], [8.5, 'sleepy']]);
    clawd(620, G, U, mood);
    const h = headAt(mood.sq || 0);
    bfly(h[0], h[1] - 20, 44, lt, { open: .18 + .1 * Math.abs(Math.sin(lt * .9)), fr: 2 });
    const eye = toScreen(620, G - 4 * U); camEnd();
    timeline(5, lt); title('Night', lt, dur, 5);
    irisOpen(lt, ...eye); irisClose(lt, dur, ...eye);
  }

  // G: Tomorrow: dawn, the butterfly wakes first, Clawd stretches and waves it off (rhymes with the opening)
  function shotMorning(t, lt, dur) {
    camBegin(960 + 10 * Math.sin(lt * .4), 540, 1.03);
    backdrop(t, true, 3);
    const mood = emotions(lt, [[0, 'sleepy'], [3.0, 'surprised'], [3.6, 'excited'], [4.4, 'happy', { lookX: .9 }]]);
    const st = lt > 3.4 && lt < 4.6 ? Math.sin(seg(lt, 3.4, 4.6) * Math.PI) * 1.4 : 0, wave = lt > 5.2 && lt < 7.8;
    const cl = { ...mood }; if (st) { cl.aL = st; cl.aR = st; } if (wave) cl.aR = 1.1 + .5 * Math.sin((lt - 5.2) * 12);
    clawd(620, G, U, cl);
    const h = headAt(cl.sq || 0);
    const b = kf(lt, [[0, [h[0], h[1] - 22]], [2.6, [h[0], h[1] - 22]], [3.5, [700, 430]], [4.4, [820, 380]], [5.4, [1300, 330]], [6.6, [1750, 230]], [7.2, [1500, 320]], [7.9, [1050, 380]], [8.6, [760, 470]]], ease);
    const rest = lt < 2.6, away = lt > 2.6 && lt < 8.6;
    bfly(b[0], b[1] + (away ? 14 * Math.sin(lt * 5) : 0), 44, lt, { open: rest ? .15 + .85 * seg(lt, 1.2, 2.6) : 1, fr: rest && lt < 1.2 ? 2 : 16, rot: away ? .15 * Math.sin(lt * 3) : 0 });
    const eye = toScreen(620, G - 4 * U); camEnd();
    timeline(6, lt); title('Tomorrow', lt, dur, 6);
    irisOpen(lt, ...eye); irisClose(lt, dur, ...eye, .75);
  }

  const scaled = (fn, k) => (t, lt, dur) => fn(t, lt / k, dur / k);
  shots([[0, scaled(shotNap, 5.5 / 4.2)], [5.5, scaled(shotChase, 5.8 / 4.4)], [11.3, scaled(shotFriends, 7.2 / 5.6)], [18.5, shotPicnic], [28.5, shotRain], [39.5, shotNight], [50.5, shotMorning]]);
})();
