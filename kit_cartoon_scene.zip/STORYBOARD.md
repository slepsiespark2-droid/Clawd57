Logline: Clawd naps, wants the butterfly, chases it and fails, then gives up - and the butterfly comes to him.
World: warm cream paper, peach-blue sky, sage hills; doodle look, orange mascot, timeline dots along the bottom.
Motif: the butterfly. Opening = Clawd asleep on the hill; ending = Clawd asleep on the hill, butterfly on his head.
Arc: sleepy > surprised > excited > (chase) determined > sad > hopeful > starstruck > love > sleepy (content).
Shots:
 A "Nap"     0-4.2   [iris open]  butterfly drifts in, hovers at Clawd's face, flits off; Clawd wakes, turns, crouches. [iris close + speed lines]
 B "Chase"   4.2-8.6 [iris open]  run, lunge, miss, slump; butterfly circles back as Clawd looks up. [iris close]
 C "Friends" 8.6-14.2 [iris open] butterfly lands on his head; freeze, love, drifts off to sleep. [iris close, hold]
